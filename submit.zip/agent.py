import numpy as np

class Agent():
    def __init__(self, module_path: str):
        self.container_info = None
        self.packed_items = []
        
    def get_init_states(self, init_states: dict):
        self.container_info = init_states.get('container_list', [{}])[0]
        self.packed_items = []
        return True
    
    def optimize(self, item_list: list):
        sorted_items = sorted(item_list, key=lambda x: (
            -x.get('is_prioritized', False),
            x.get('mass', 0),
            x['length'] * x['width'] * x['height']
        ))
        return [item['index'] for item in sorted_items]
    
    def policy(self, observation: dict):
        pool_list = observation.get('pool_list', [])
        if not pool_list:
            return self._default_action()
        
        target_item = pool_list[0]
        container = observation.get('container_list', [{}])[0]
        self.packed_items = container.get('packed_items', [])
        
        pos = self._find_position(container, target_item)
        
        return {
            'item_idx': 0,
            'container_idx': 0,
            'place_pos': pos,
            'orientation': 0
        }
    
    def _find_position(self, container, item):
        length = container.get('length', 2.0)
        width = container.get('width', 1.45)
        height = container.get('height', 1.61)
        thickness = container.get('thickness', 0.04)
        cut_x = container.get('cut_x', 0.44)
        cut_y = container.get('cut_y', 0.4)
        
        inner_length = length - 2 * thickness  # 1.92
        inner_width = width - 2 * thickness    # 1.37
        
        il = item['length'] / 2
        iw = item['width'] / 2
        ih = item['height'] / 2
        
        z_floor = thickness + ih + 0.02
        
        # STRATEGY: Only use BACK portion of container (Y > 0.15)
        # This leaves front clear for transport at X=0.3
        # Container inner Y range: -0.685 to 0.685
        # Use only Y from 0.15 to 0.535 (back 60%)
        
        margin_x = 0.55   # from side walls
        margin_y_back = 0.05  # from back wall - minimal to prevent sliding
        min_y = 0.4      # front boundary of placement zone - only back half
        
        max_x = inner_length / 2 - il - margin_x
        min_x = -max_x
        max_y = inner_width / 2 - iw - margin_y_back
        
        # Two columns far from transport path (X=0.3)
        col_positions = [-0.6, 0.6]
        col_positions = [x for x in col_positions if min_x <= x <= max_x]
        
        # Row positions: only in BACK portion (y > 0.15)
        row_positions = []
        y = max_y
        while y >= min_y:
            row_positions.append(y)
            y -= max(iw * 2, 0.35)
        
        # Try positions: back rows first
        for y in row_positions:
            for x in col_positions:
                if self._near_cut_corner(x, y, length, width, cut_x, cut_y, thickness):
                    continue
                if self._check_collision(x, y, z_floor, item):
                    continue
                return np.array([x, y, z_floor], dtype=np.float32)
        
        # Fallback: single column at right side
        for y in row_positions:
            x = max_x if max_x > 0.3 else -max_x
            if self._near_cut_corner(x, y, length, width, cut_x, cut_y, thickness):
                continue
            if self._check_collision(x, y, z_floor, item):
                continue
            return np.array([x, y, z_floor], dtype=np.float32)
        
        return np.array([0.3, 0.0, 0.2], dtype=np.float32)
    
    def _near_cut_corner(self, x, y, length, width, cut_x, cut_y, thickness):
        cut_x_min = -length / 2 + thickness
        cut_x_max = -length / 2 + thickness + cut_x
        cut_y_min = width / 2 - thickness - cut_y
        cut_y_max = width / 2 - thickness
        return cut_x_min <= x <= cut_x_max and cut_y_min <= y <= cut_y_max
    
    def _check_collision(self, x, y, z, item):
        il = item['length'] / 2
        iw = item['width'] / 2
        ih = item['height'] / 2
        
        for p in self.packed_items:
            p_pos = p.get('pos')
            if not p_pos or len(p_pos) < 3:
                continue
            px, py, pz = p_pos
            pl = p.get('length', 0) / 2
            pw = p.get('width', 0) / 2
            ph = p.get('height', 0) / 2
            
            gap_x = abs(x - px) - (il + pl) - 0.01
            gap_y = abs(y - py) - (iw + pw) - 0.01
            gap_z = abs(z - pz) - (ih + ph) - 0.01
            
            if gap_x <= 0 and gap_y <= 0:
                return True  # collision in XY plane
            if gap_x <= 0 and gap_y <= 0 and gap_z <= 0:
                return True  # collision in 3D
        return False
    
    def _default_action(self):
        return {
            'item_idx': 0,
            'container_idx': 0,
            'place_pos': np.array([0.3, 0.0, 0.2], dtype=np.float32),
            'orientation': 0
        }